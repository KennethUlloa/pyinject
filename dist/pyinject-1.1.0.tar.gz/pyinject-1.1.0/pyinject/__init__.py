from .dependency import Dependency, DependantDependency
from .injection import inject
