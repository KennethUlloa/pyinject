from .dependency import Dependency, SingletonDependency
from .injection import inject
